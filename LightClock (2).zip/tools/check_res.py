"""Проверка ресурсов Android-проекта без aapt2 и генерация R.java для javac.
usage: python3 check_res.py <res_dir> <manifest> <attrs.txt> <styles.txt> <layouts.txt> <out_R.java> <package>
"""
import os, re, sys
import xml.etree.ElementTree as ET

res, manifest, attrs_f, styles_f, layouts_f, out_r, pkg = sys.argv[1:8]
A = '{http://schemas.android.com/apk/res/android}'
fw_attrs = set(open(attrs_f).read().split())
fw_styles = set(s.replace('_', '.') for s in open(styles_f).read().split())
fw_layouts = set(open(layouts_f).read().split())
errors = []
res_types = {}   # type -> set(names)
ids = set()
refs = []        # (file, ref)

def add(t, n):
    res_types.setdefault(t, set()).add(n)

def scan_attrs(fn, el):
    for k, v in el.attrib.items():
        if k.startswith(A):
            name = k[len(A):]
            if name not in fw_attrs:
                errors.append(f'{fn}: неизвестный атрибут android:{name}')
        for m in re.finditer(r'@(\+?)(android:)?([a-z]+)/([A-Za-z0-9_.]+)', v):
            plus, fw, t, n = m.groups()
            if t == 'id' and plus:
                ids.add(n)
            elif not fw:
                refs.append((fn, t, n))
            elif t == 'style' and n not in fw_styles:
                errors.append(f'{fn}: нет стиля @android:style/{n}')
            elif t == 'layout' and n not in fw_layouts:
                errors.append(f'{fn}: нет @android:layout/{n}')
        if v.startswith('?android:attr/') and v[14:] not in fw_attrs:
            errors.append(f'{fn}: нет ?android:attr/{v[14:]}')
    for c in el:
        scan_attrs(fn, c)

for d in sorted(os.listdir(res)):
    t = d.split('-')[0]
    for f in sorted(os.listdir(os.path.join(res, d))):
        p = os.path.join(res, d, f)
        fn = f'{d}/{f}'
        try:
            root = ET.parse(p).getroot()
        except ET.ParseError as e:
            errors.append(f'{fn}: XML ошибка {e}')
            continue
        if t == 'values':
            for el in root:
                kind = el.tag if el.tag != 'string-array' else 'array'
                name = el.get('name')
                if kind == 'style':
                    add('style', name.replace('.', '_'))
                    par = el.get('parent', '')
                    if par.startswith('@android:style/') and par[15:] not in fw_styles:
                        errors.append(f'{fn}: нет родителя {par}')
                    for it in el:
                        an = it.get('name')
                        if an.startswith('android:') and an[8:] not in fw_attrs:
                            errors.append(f'{fn}: стиль {name}: неизвестный атрибут {an}')
                        for m in re.finditer(r'@([a-z]+)/([A-Za-z0-9_]+)', it.text or ''):
                            refs.append((fn, m.group(1), m.group(2)))
                else:
                    add(kind, name)
                if kind == 'string':
                    txt = ''.join(el.itertext())
                    if re.search(r"(?<!\\)'", txt):
                        errors.append(f'{fn}: неэкранированный апостроф в {name}')
                    if re.search(r'%(?!(\d+\$)?[dsf])', txt.replace('%%', '')):
                        errors.append(f'{fn}: подозрительный % в {name}')
        else:
            add(t, os.path.splitext(f)[0])
            scan_attrs(fn, root)

mroot = ET.parse(manifest).getroot()
scan_attrs('AndroidManifest.xml', mroot)

for fn, t, n in refs:
    if n not in res_types.get(t, set()) and not (t == 'style' and n.replace('.', '_') in res_types.get('style', set())):
        errors.append(f'{fn}: ссылка @{t}/{n} не найдена')

add('id', None); res_types['id'] = ids
lines = [f'package {pkg};', 'public final class R {']
i = 0x7f000000
for t, names in sorted(res_types.items()):
    lines.append(f'  public static final class {t} {{')
    for n in sorted(x for x in names if x):
        i += 1
        lines.append(f'    public static final int {n} = {i};')
    lines.append('  }')
lines.append('}')
open(out_r, 'w').write('\n'.join(lines))

print(f'Ресурсов: {sum(len(v) for v in res_types.values())}, id: {len(ids)}')
if errors:
    print('ОШИБКИ:'); print('\n'.join(errors)); sys.exit(1)
print('Ресурсы: ошибок нет')
