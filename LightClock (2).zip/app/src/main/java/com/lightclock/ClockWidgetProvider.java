package com.lightclock;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Locale;

/**
 * Провайдер виджета.
 *
 * Ключевая идея энергоэффективности: время рисует TextClock, который живёт в процессе
 * лаунчера и сам переключает секунды. Наш процесс запускается только при добавлении,
 * настройке или смене языка — без сервисов, будильников (AlarmManager) и wake lock'ов.
 * Когда рабочий стол не виден, TextClock (Android 7+) останавливает тики сам.
 */
public class ClockWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) update(context, manager, id);
    }

    @Override
    public void onDeleted(Context context, int[] ids) {
        for (int id : ids) WidgetConfig.delete(context, id);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // Шаблон даты зависит от языка системы — перерисовываем все виджеты.
        if (Intent.ACTION_LOCALE_CHANGED.equals(intent.getAction())) {
            updateAll(context);
            return;
        }
        super.onReceive(context, intent);
    }

    static void updateAll(Context context) {
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        if (m == null) return;
        int[] ids = m.getAppWidgetIds(new ComponentName(context, ClockWidgetProvider.class));
        for (int id : ids) update(context, m, id);
    }

    static void update(Context context, AppWidgetManager manager, int id) {
        manager.updateAppWidget(id, build(context, id, WidgetConfig.load(context, id)));
    }

    /** Строит RemoteViews. Используется и для рабочего стола, и для предпросмотра в настройках. */
    static RemoteViews build(Context ctx, int id, WidgetConfig c) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), c.layoutRes());

        // --- время ---
        String p24 = c.timePattern(true);
        String p12 = c.timePattern(false);
        String f24, f12;
        switch (c.hourMode) {
            case WidgetConfig.HOUR_24: f24 = p24; f12 = p24; break;
            case WidgetConfig.HOUR_12: f24 = p12; f12 = p12; break;
            default:                   f24 = p24; f12 = p12; break;
        }
        rv.setCharSequence(R.id.time, "setFormat24Hour", f24);
        rv.setCharSequence(R.id.time, "setFormat12Hour", f12);
        rv.setTextColor(R.id.time, c.textColor);
        rv.setTextViewTextSize(R.id.time, TypedValue.COMPLEX_UNIT_SP, c.timeSizeSp);
        String tz = c.timeZone.isEmpty() ? null : c.timeZone; // null = системный пояс
        rv.setString(R.id.time, "setTimeZone", tz);

        // --- дата ---
        if (c.showDate) {
            String pattern = DateFormat.getBestDateTimePattern(
                    Locale.getDefault(), WidgetConfig.DATE_SKELETONS[c.dateStyle]);
            rv.setViewVisibility(R.id.date, View.VISIBLE);
            rv.setCharSequence(R.id.date, "setFormat24Hour", pattern);
            rv.setCharSequence(R.id.date, "setFormat12Hour", pattern);
            rv.setString(R.id.date, "setTimeZone", tz);
            rv.setTextColor(R.id.date, dim(c.textColor));
            rv.setTextViewTextSize(R.id.date, TypedValue.COMPLEX_UNIT_SP, c.dateSizeSp);
        } else {
            rv.setViewVisibility(R.id.date, View.GONE);
        }

        // --- фон ---
        int alpha = Math.round(c.bgOpacity * 255f / 100f);
        if (alpha == 0) {
            rv.setViewVisibility(R.id.bg, View.GONE);
        } else {
            rv.setViewVisibility(R.id.bg, View.VISIBLE);
            rv.setImageViewResource(R.id.bg, c.bgShapeRes());
            rv.setInt(R.id.bg, "setColorFilter", c.bgColor | 0xFF000000);
            rv.setInt(R.id.bg, "setImageAlpha", alpha);
        }

        // --- выравнивание ---
        int g;
        switch (c.align) {
            case WidgetConfig.ALIGN_START: g = Gravity.START; break;
            case WidgetConfig.ALIGN_END:   g = Gravity.END; break;
            default:                       g = Gravity.CENTER_HORIZONTAL; break;
        }
        rv.setInt(R.id.content, "setGravity", g | Gravity.CENTER_VERTICAL);

        // --- нажатие ---
        PendingIntent pi = tapIntent(ctx, id, c.tap);
        if (pi != null) rv.setOnClickPendingIntent(R.id.root, pi);
        return rv;
    }

    private static PendingIntent tapIntent(Context ctx, int id, int tap) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        Intent i;
        switch (tap) {
            case WidgetConfig.TAP_APP:
                i = new Intent(ctx, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                break;
            case WidgetConfig.TAP_SETTINGS:
                i = new Intent(ctx, WidgetConfigActivity.class)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        // уникальный data — чтобы PendingIntent разных виджетов не сливались
                        .setData(Uri.parse("lightclock://widget/" + id));
                break;
            case WidgetConfig.TAP_ALARMS:
                i = new Intent(AlarmClock.ACTION_SHOW_ALARMS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                break;
            default:
                return null;
        }
        return PendingIntent.getActivity(ctx, id, i, flags);
    }

    /** Цвет даты — тот же, что у времени, но на 15% прозрачнее. */
    static int dim(int color) {
        int a = (color >>> 24) * 85 / 100;
        return (a << 24) | (color & 0x00FFFFFF);
    }
}
