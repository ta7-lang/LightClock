package com.lightclock;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RemoteViews;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** Настройка виджета с живым предпросмотром (используется тот же RemoteViews, что и на рабочем столе). */
public class WidgetConfigActivity extends Activity {

    private static final int[] TEXT_SWATCHES = {
            0xFFFFFFFF, 0xFFE0E0E0, 0xFF9E9E9E, 0xFF000000, 0xFFFF6D3A, 0xFFFFC107,
            0xFF8BC34A, 0xFF00E676, 0xFF00BCD4, 0xFF2196F3, 0xFF7C4DFF, 0xFFE91E63
    };
    private static final int[] BG_SWATCHES = {
            0xFF000000, 0xFF1B1F27, 0xFF37474F, 0xFF616161, 0xFFFFFFFF, 0xFF0D47A1,
            0xFF1B5E20, 0xFF4A148C, 0xFFB71C1C, 0xFFE65100, 0xFF006064, 0xFF3E2723
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable renderPreview = new Runnable() {
        @Override
        public void run() {
            drawPreview();
        }
    };

    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private WidgetConfig cfg;
    private boolean binding; // true, пока UI заполняется из cfg — чтобы слушатели не срабатывали

    private FrameLayout preview;
    private View previewBox;
    private CheckBox previewLight, seconds, leadingZero, showDate;
    private Spinner font, hourMode, dateStyle, bgShape, align, timezone, tap;
    private SeekBar timeSize, dateSize, bgOpacity;
    private TextView timeSizeLabel, dateSizeLabel, bgOpacityLabel;
    private EditText textHex, bgHex;
    private String[] tzIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            widgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }
        // Если пользователь выйдет «назад», лаунчер не должен добавлять виджет.
        setResult(RESULT_CANCELED, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        setContentView(R.layout.activity_config);
        cfg = WidgetConfig.load(this, widgetId);
        findViews();
        setupTimeZones();
        setupSwatches((LinearLayout) findViewById(R.id.text_swatches), TEXT_SWATCHES, true);
        setupSwatches((LinearLayout) findViewById(R.id.bg_swatches), BG_SWATCHES, false);
        timeSize.setMax(WidgetConfig.TIME_SIZE_MAX - WidgetConfig.TIME_SIZE_MIN);
        dateSize.setMax(WidgetConfig.DATE_SIZE_MAX - WidgetConfig.DATE_SIZE_MIN);
        bgOpacity.setMax(100);
        bindFromConfig();
        attachListeners();
        drawPreview();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(renderPreview);
        super.onDestroy();
    }

    private void findViews() {
        preview = findViewById(R.id.preview);
        previewBox = findViewById(R.id.preview_box);
        previewLight = findViewById(R.id.preview_light);
        font = findViewById(R.id.font);
        hourMode = findViewById(R.id.hour_mode);
        seconds = findViewById(R.id.seconds);
        leadingZero = findViewById(R.id.leading_zero);
        timeSize = findViewById(R.id.time_size);
        timeSizeLabel = findViewById(R.id.time_size_label);
        textHex = findViewById(R.id.text_hex);
        showDate = findViewById(R.id.show_date);
        dateStyle = findViewById(R.id.date_style);
        dateSize = findViewById(R.id.date_size);
        dateSizeLabel = findViewById(R.id.date_size_label);
        bgHex = findViewById(R.id.bg_hex);
        bgOpacity = findViewById(R.id.bg_opacity);
        bgOpacityLabel = findViewById(R.id.bg_opacity_label);
        bgShape = findViewById(R.id.bg_shape);
        align = findViewById(R.id.align);
        timezone = findViewById(R.id.timezone);
        tap = findViewById(R.id.tap);
    }

    private void setupTimeZones() {
        List<String> ids = new ArrayList<>();
        for (String id : TimeZone.getAvailableIDs()) {
            // Оставляем только «Регион/Город», без устаревших аббревиатур и Etc/GMT+N.
            if (id.indexOf('/') > 0 && !id.startsWith("Etc/") && !id.startsWith("SystemV/")) ids.add(id);
        }
        String[] sorted = ids.toArray(new String[0]);
        Arrays.sort(sorted);
        tzIds = new String[sorted.length + 1];
        tzIds[0] = "";
        System.arraycopy(sorted, 0, tzIds, 1, sorted.length);

        long now = System.currentTimeMillis();
        String[] labels = new String[tzIds.length];
        labels[0] = getString(R.string.tz_system);
        for (int i = 1; i < tzIds.length; i++) {
            int off = TimeZone.getTimeZone(tzIds[i]).getOffset(now) / 60000;
            int a = Math.abs(off);
            labels[i] = String.format(Locale.US, "%s  (UTC%s%02d:%02d)",
                    tzIds[i].replace('_', ' '), off < 0 ? "−" : "+", a / 60, a % 60);
        }
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timezone.setAdapter(ad);
    }

    private void setupSwatches(LinearLayout row, int[] colors, final boolean isText) {
        float d = getResources().getDisplayMetrics().density;
        int size = Math.round(36 * d), margin = Math.round(4 * d);
        for (final int color : colors) {
            View v = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            g.setStroke(Math.max(1, Math.round(d)), 0xFF888888);
            v.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMargins(margin, margin, margin, margin);
            v.setLayoutParams(lp);
            v.setContentDescription(hex(color));
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Для текста сохраняем прежнюю прозрачность, если она была задана вручную.
                    if (isText) {
                        cfg.textColor = (cfg.textColor & 0xFF000000) == 0
                                ? color : (cfg.textColor & 0xFF000000) | (color & 0x00FFFFFF);
                        setTextQuiet(textHex, hex(cfg.textColor));
                    } else {
                        cfg.bgColor = color | 0xFF000000;
                        setTextQuiet(bgHex, hex(cfg.bgColor).substring(0, 1) + hex(cfg.bgColor).substring(3));
                    }
                    schedulePreview();
                }
            });
            row.addView(v);
        }
    }

    /** Заполняет все элементы из cfg. */
    private void bindFromConfig() {
        binding = true;
        font.setSelection(cfg.font);
        hourMode.setSelection(cfg.hourMode);
        seconds.setChecked(cfg.seconds);
        leadingZero.setChecked(cfg.leadingZero);
        timeSize.setProgress(cfg.timeSizeSp - WidgetConfig.TIME_SIZE_MIN);
        textHex.setText(hex(cfg.textColor));
        showDate.setChecked(cfg.showDate);
        dateStyle.setSelection(cfg.dateStyle);
        dateSize.setProgress(cfg.dateSizeSp - WidgetConfig.DATE_SIZE_MIN);
        bgHex.setText(hex(cfg.bgColor).substring(0, 1) + hex(cfg.bgColor).substring(3));
        bgOpacity.setProgress(cfg.bgOpacity);
        bgShape.setSelection(cfg.bgShape);
        align.setSelection(cfg.align);
        int tzIndex = 0;
        for (int i = 1; i < tzIds.length; i++) {
            if (tzIds[i].equals(cfg.timeZone)) { tzIndex = i; break; }
        }
        timezone.setSelection(tzIndex);
        tap.setSelection(cfg.tap);
        updateLabels();
        updateEnabled();
        binding = false;
    }

    private void attachListeners() {
        AdapterView.OnItemSelectedListener spinners = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                if (binding) return;
                int v = parent.getId();
                if (v == R.id.font) cfg.font = pos;
                else if (v == R.id.hour_mode) cfg.hourMode = pos;
                else if (v == R.id.date_style) cfg.dateStyle = pos;
                else if (v == R.id.bg_shape) cfg.bgShape = pos;
                else if (v == R.id.align) cfg.align = pos;
                else if (v == R.id.timezone) cfg.timeZone = tzIds[pos];
                else if (v == R.id.tap) cfg.tap = pos;
                schedulePreview();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        };
        for (Spinner s : new Spinner[]{font, hourMode, dateStyle, bgShape, align, timezone, tap}) {
            s.setOnItemSelectedListener(spinners);
        }

        CompoundButton.OnCheckedChangeListener checks = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                if (binding) return;
                int v = b.getId();
                if (v == R.id.seconds) cfg.seconds = on;
                else if (v == R.id.leading_zero) cfg.leadingZero = on;
                else if (v == R.id.show_date) cfg.showDate = on;
                else if (v == R.id.preview_light) {
                    previewBox.setBackgroundColor(on ? 0xFFE8EAED : 0xFF3A4250);
                    return;
                }
                updateEnabled();
                schedulePreview();
            }
        };
        for (CheckBox c : new CheckBox[]{seconds, leadingZero, showDate, previewLight}) {
            c.setOnCheckedChangeListener(checks);
        }

        SeekBar.OnSeekBarChangeListener seeks = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (binding) return;
                int v = s.getId();
                if (v == R.id.time_size) cfg.timeSizeSp = WidgetConfig.TIME_SIZE_MIN + p;
                else if (v == R.id.date_size) cfg.dateSizeSp = WidgetConfig.DATE_SIZE_MIN + p;
                else if (v == R.id.bg_opacity) cfg.bgOpacity = p;
                updateLabels();
                schedulePreview();
            }

            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        };
        for (SeekBar s : new SeekBar[]{timeSize, dateSize, bgOpacity}) s.setOnSeekBarChangeListener(seeks);

        textHex.addTextChangedListener(new HexWatcher(textHex, true));
        bgHex.addTextChangedListener(new HexWatcher(bgHex, false));

        findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });
        findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        findViewById(R.id.reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cfg = new WidgetConfig();
                bindFromConfig();
                schedulePreview();
            }
        });
    }

    private void save() {
        cfg.save(this, widgetId);
        AppWidgetManager m = AppWidgetManager.getInstance(this);
        if (m != null) ClockWidgetProvider.update(this, m, widgetId);
        setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        finish();
    }

    private void updateLabels() {
        timeSizeLabel.setText(getString(R.string.time_size, cfg.timeSizeSp));
        dateSizeLabel.setText(getString(R.string.date_size, cfg.dateSizeSp));
        bgOpacityLabel.setText(getString(R.string.bg_opacity, cfg.bgOpacity));
    }

    private void updateEnabled() {
        dateStyle.setEnabled(cfg.showDate);
        dateSize.setEnabled(cfg.showDate);
    }

    private void schedulePreview() {
        // Склеиваем частые изменения (перетаскивание ползунка) в одну перерисовку.
        handler.removeCallbacks(renderPreview);
        handler.postDelayed(renderPreview, 40);
    }

    private void drawPreview() {
        RemoteViews rv = ClockWidgetProvider.build(this, widgetId, cfg);
        preview.removeAllViews();
        View v = rv.apply(getApplicationContext(), preview);
        v.setClickable(false); // в предпросмотре нажатие ничего не открывает
        v.setOnClickListener(null);
        preview.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void setTextQuiet(EditText e, String s) {
        binding = true;
        e.setText(s);
        e.setSelection(s.length());
        binding = false;
    }

    static String hex(int color) {
        return String.format(Locale.US, "#%08X", color);
    }

    /** Разбирает #RRGGBB / #AARRGGBB; при ошибке показывает подсказку, не трогая cfg. */
    private final class HexWatcher implements TextWatcher {
        private final EditText field;
        private final boolean isText;

        HexWatcher(EditText field, boolean isText) {
            this.field = field;
            this.isText = isText;
        }

        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }

        @Override
        public void afterTextChanged(Editable s) {
            if (binding) return;
            String t = s.toString().trim();
            if (!t.startsWith("#")) t = "#" + t;
            if (t.length() != 7 && t.length() != 9) {
                field.setError(null);
                return; // ещё печатают
            }
            try {
                int c = Color.parseColor(t);
                field.setError(null);
                if (isText) cfg.textColor = c;
                else cfg.bgColor = c | 0xFF000000; // прозрачность фона задаётся ползунком
                schedulePreview();
            } catch (IllegalArgumentException e) {
                field.setError(getString(R.string.bad_color));
            }
        }
    }
}
