package com.lightclock;

import android.app.Activity;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Полноэкранные часы.
 *
 * Тик выравнивается по границе секунды системных часов: следующий кадр планируется
 * ровно на момент смены секунды, поэтому отставания нет и ошибка не накапливается.
 * В onStop тики полностью останавливаются — в фоне активити не тратит ни CPU, ни батарею.
 * Пока на экране только часы, работа — одно обновление TextView в секунду.
 */
public class MainActivity extends Activity {

    private static final String PREFS = "app";
    private static final String KEY_KEEP_ON = "keep_on";
    private static final long BURN_IN_SHIFT_MS = 60_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Date date = new Date();          // переиспользуется, чтобы не создавать объекты каждую секунду
    private final Calendar calendar = Calendar.getInstance();

    private TextView timeView;
    private TextView dateView;
    private View clockBox;
    private View controls;
    private CheckBox keepOn;

    private SimpleDateFormat timeFormat;
    private SimpleDateFormat dateFormat;
    private int lastDayKey = -1;
    private String fitSample = "";
    private long lastShift;
    private boolean receiverRegistered;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            render(now);
            // Ждём ровно до следующей секунды (+2 мс запаса, чтобы не проснуться на 999 мс).
            long delay = 1000L - (now % 1000L) + 2L;
            handler.postAtTime(this, SystemClock.uptimeMillis() + delay);
        }
    };

    private final BroadcastReceiver timeChanged = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Пользователь или сеть поменяли время/пояс/язык — пересоздаём форматы и рисуем сразу.
            rebuildFormats();
            restartTicks();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timeView = findViewById(R.id.time);
        dateView = findViewById(R.id.date);
        clockBox = findViewById(R.id.clock_box);
        controls = findViewById(R.id.controls);
        keepOn = findViewById(R.id.keep_on);

        findViewById(R.id.root).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controls.setVisibility(controls.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });

        findViewById(R.id.add_widget).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPinWidget();
            }
        });

        final SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        keepOn.setChecked(p.getBoolean(KEY_KEEP_ON, false));
        applyKeepOn(keepOn.isChecked());
        keepOn.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                p.edit().putBoolean(KEY_KEEP_ON, checked).apply();
                applyKeepOn(checked);
            }
        });

        timeView.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int b,
                                       int ol, int ot, int or, int ob) {
                if ((r - l) != (or - ol)) fitTimeText();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        rebuildFormats();
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_TIME_CHANGED);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        f.addAction(Intent.ACTION_LOCALE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(timeChanged, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(timeChanged, f);
        }
        receiverRegistered = true;
        restartTicks();
    }

    @Override
    protected void onStop() {
        // Полная остановка: в фоне ничего не тикает.
        handler.removeCallbacks(tick);
        if (receiverRegistered) {
            unregisterReceiver(timeChanged);
            receiverRegistered = false;
        }
        super.onStop();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void restartTicks() {
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    private void rebuildFormats() {
        Locale locale = Locale.getDefault();
        boolean is24 = DateFormat.is24HourFormat(this);
        timeFormat = new SimpleDateFormat(is24 ? "HH:mm:ss" : "h:mm:ss a", locale);
        dateFormat = new SimpleDateFormat(
                DateFormat.getBestDateTimePattern(locale, "EEEEdMMMMyyyy"), locale);
        // TimeZone берётся текущий системный: SimpleDateFormat запоминает пояс при создании.
        calendar.setTimeZone(java.util.TimeZone.getDefault());
        lastDayKey = -1;
        String sample = is24 ? "00:00:00" : "10:00:00 " + timeFormat.getDateFormatSymbols().getAmPmStrings()[1];
        if (!sample.equals(fitSample)) {
            fitSample = sample;
            fitTimeText();
        }
    }

    private void render(long now) {
        date.setTime(now);
        timeView.setText(timeFormat.format(date));

        calendar.setTimeInMillis(now);
        int dayKey = calendar.get(Calendar.YEAR) * 1000 + calendar.get(Calendar.DAY_OF_YEAR);
        if (dayKey != lastDayKey) { // дату пересчитываем только при смене дня
            lastDayKey = dayKey;
            String d = dateFormat.format(date);
            if (!d.isEmpty()) d = d.substring(0, 1).toUpperCase(Locale.getDefault()) + d.substring(1);
            dateView.setText(d);
        }

        // Защита AMOLED от выгорания при «не гасить экран»: раз в минуту чуть сдвигаем часы.
        if (keepOn.isChecked() && now - lastShift >= BURN_IN_SHIFT_MS) {
            lastShift = now;
            float range = 8 * getResources().getDisplayMetrics().density;
            clockBox.setTranslationX((float) ((Math.random() * 2 - 1) * range));
            clockBox.setTranslationY((float) ((Math.random() * 2 - 1) * range));
        }
    }

    /** Подбирает размер шрифта так, чтобы время занимало ~92% ширины экрана. */
    private void fitTimeText() {
        int avail = timeView.getWidth() - timeView.getPaddingLeft() - timeView.getPaddingRight();
        if (avail <= 0 || fitSample.isEmpty()) return;
        Paint paint = new Paint(timeView.getPaint());
        paint.setTextSize(100f);
        float w = paint.measureText(fitSample);
        if (w <= 0) return;
        float px = 100f * avail * 0.92f / w;
        float maxPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 220,
                getResources().getDisplayMetrics());
        px = Math.min(px, maxPx);
        if (Math.abs(px - timeView.getTextSize()) > 1f) {
            timeView.setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
        }
    }

    private void applyKeepOn(boolean on) {
        if (on) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            clockBox.setTranslationX(0);
            clockBox.setTranslationY(0);
        }
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    private void requestPinWidget() {
        AppWidgetManager m = AppWidgetManager.getInstance(this);
        if (Build.VERSION.SDK_INT >= 26 && m != null && m.isRequestPinAppWidgetSupported()) {
            // После добавления лаунчер вызовет этот PendingIntent и подставит EXTRA_APPWIDGET_ID,
            // поэтому он должен быть изменяемым (FLAG_MUTABLE на Android 12+).
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent callback = PendingIntent.getActivity(this, 0,
                    new Intent(this, WidgetConfigActivity.class), flags);
            m.requestPinAppWidget(new ComponentName(this, ClockWidgetProvider.class), null, callback);
        } else {
            Toast.makeText(this, R.string.add_widget_manual, Toast.LENGTH_LONG).show();
        }
    }
}
