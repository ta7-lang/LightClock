package com.lightclock;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Настройки одного экземпляра виджета. Хранятся в SharedPreferences с ключами вида "w{id}_{поле}".
 * Все значения при чтении проверяются, чтобы повреждённые данные не приводили к падению.
 */
final class WidgetConfig {

    static final int FONT_SANS = 0, FONT_LIGHT = 1, FONT_BOLD = 2,
            FONT_CONDENSED = 3, FONT_SERIF = 4, FONT_MONO = 5;
    private static final int[] FONT_LAYOUTS = {
            R.layout.widget_sans, R.layout.widget_light, R.layout.widget_bold,
            R.layout.widget_condensed, R.layout.widget_serif, R.layout.widget_mono
    };

    static final int HOUR_SYSTEM = 0, HOUR_24 = 1, HOUR_12 = 2;

    /** Скелеты для DateFormat.getBestDateTimePattern — порядок как в R.array.date_styles. */
    static final String[] DATE_SKELETONS = {"EEEdMMM", "EEEEdMMMM", "ddMMyyyy", "dMMMMyyyy", "EEEEd"};

    private static final int[] BG_SHAPES = {
            R.drawable.bg_round_l, R.drawable.bg_round_s, R.drawable.bg_square, R.drawable.bg_circle
    };

    static final int ALIGN_START = 0, ALIGN_CENTER = 1, ALIGN_END = 2;

    static final int TAP_APP = 0, TAP_SETTINGS = 1, TAP_ALARMS = 2, TAP_NONE = 3;

    static final int TIME_SIZE_MIN = 16, TIME_SIZE_MAX = 120;
    static final int DATE_SIZE_MIN = 8, DATE_SIZE_MAX = 48;

    int font = FONT_SANS;
    int hourMode = HOUR_SYSTEM;
    boolean seconds = true;
    boolean leadingZero = true;
    int timeSizeSp = 44;
    int textColor = 0xFFFFFFFF;

    boolean showDate = true;
    int dateStyle = 0;
    int dateSizeSp = 15;

    int bgColor = 0xFF000000;
    int bgOpacity = 35; // проценты 0..100
    int bgShape = 0;

    int align = ALIGN_CENTER;
    String timeZone = ""; // пусто = системный пояс
    int tap = TAP_APP;

    private static final String PREFS = "widgets";

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String k(int id, String field) {
        return "w" + id + "_" + field;
    }

    static WidgetConfig load(Context c, int id) {
        SharedPreferences p = prefs(c);
        WidgetConfig w = new WidgetConfig();
        w.font = clamp(p.getInt(k(id, "font"), w.font), 0, FONT_LAYOUTS.length - 1);
        w.hourMode = clamp(p.getInt(k(id, "hour"), w.hourMode), 0, 2);
        w.seconds = p.getBoolean(k(id, "sec"), w.seconds);
        w.leadingZero = p.getBoolean(k(id, "lz"), w.leadingZero);
        w.timeSizeSp = clamp(p.getInt(k(id, "tsize"), w.timeSizeSp), TIME_SIZE_MIN, TIME_SIZE_MAX);
        w.textColor = p.getInt(k(id, "tcolor"), w.textColor);
        w.showDate = p.getBoolean(k(id, "date"), w.showDate);
        w.dateStyle = clamp(p.getInt(k(id, "dstyle"), w.dateStyle), 0, DATE_SKELETONS.length - 1);
        w.dateSizeSp = clamp(p.getInt(k(id, "dsize"), w.dateSizeSp), DATE_SIZE_MIN, DATE_SIZE_MAX);
        w.bgColor = p.getInt(k(id, "bcolor"), w.bgColor);
        w.bgOpacity = clamp(p.getInt(k(id, "bop"), w.bgOpacity), 0, 100);
        w.bgShape = clamp(p.getInt(k(id, "bshape"), w.bgShape), 0, BG_SHAPES.length - 1);
        w.align = clamp(p.getInt(k(id, "align"), w.align), 0, 2);
        String tz = p.getString(k(id, "tz"), w.timeZone);
        w.timeZone = tz == null ? "" : tz;
        w.tap = clamp(p.getInt(k(id, "tap"), w.tap), 0, 3);
        return w;
    }

    void save(Context c, int id) {
        prefs(c).edit()
                .putInt(k(id, "font"), font)
                .putInt(k(id, "hour"), hourMode)
                .putBoolean(k(id, "sec"), seconds)
                .putBoolean(k(id, "lz"), leadingZero)
                .putInt(k(id, "tsize"), timeSizeSp)
                .putInt(k(id, "tcolor"), textColor)
                .putBoolean(k(id, "date"), showDate)
                .putInt(k(id, "dstyle"), dateStyle)
                .putInt(k(id, "dsize"), dateSizeSp)
                .putInt(k(id, "bcolor"), bgColor)
                .putInt(k(id, "bop"), bgOpacity)
                .putInt(k(id, "bshape"), bgShape)
                .putInt(k(id, "align"), align)
                .putString(k(id, "tz"), timeZone)
                .putInt(k(id, "tap"), tap)
                .apply();
    }

    static void delete(Context c, int id) {
        SharedPreferences p = prefs(c);
        SharedPreferences.Editor e = p.edit();
        String prefix = "w" + id + "_";
        for (String key : p.getAll().keySet()) {
            if (key.startsWith(prefix)) e.remove(key);
        }
        e.apply();
    }

    int layoutRes() {
        return FONT_LAYOUTS[font];
    }

    int bgShapeRes() {
        return BG_SHAPES[bgShape];
    }

    /** Шаблон времени для TextClock. */
    String timePattern(boolean use24) {
        String h = use24 ? (leadingZero ? "HH" : "H") : (leadingZero ? "hh" : "h");
        String s = h + ":mm" + (seconds ? ":ss" : "");
        return use24 ? s : s + " a";
    }

    static int clamp(int v, int min, int max) {
        return v < min ? min : (v > max ? max : v);
    }
}
